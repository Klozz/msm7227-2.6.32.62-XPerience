/* configuration management identifiers */
#define IXJ_VER_MAJOR 1
#define IXJ_VER_MINOR 0
#define IXJ_BLD_VER   1
