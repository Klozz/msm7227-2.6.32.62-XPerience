
extern void zorro_name_device(struct zorro_dev *z);
extern int zorro_create_sysfs_dev_files(struct zorro_dev *z);

