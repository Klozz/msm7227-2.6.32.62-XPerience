/* temporary measure */
extern int __pxa2xx_drv_pcmcia_probe(struct device *);

